const {
    normal: ____,
    nest,
    rock,
    roid,
    portal: port,
    wall,
    base1: bas1,
    baseprotected1: bap1,
    baseprotected2: bap2,
    baseprotected3: bap3,
    baseprotected4: bap4,
    baseprotected5: bap5,
    baseprotected6: bap6,
    baseprotected7: bap7,
    baseprotected8: bap8,
    atmg,
    imagetest3: img3,
    imagetesterror: imge
} = tileClass;  

let room_tiles_test = [
    [____, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____],
    [____, ____, ____, ____, ____, ____, ____, ____, wall, wall, wall, wall, wall, wall, wall, ____, ____, ____, ____, ____, ____, ____, ____],
    [____, ____, ____, ____, ____, ____, ____, ____, wall, ____, rock, nest, roid, ____, wall, ____, ____, ____, ____, ____, ____, ____, ____],
    [____, ____, ____, ____, ____, ____, ____, ____, wall, ____, ____, ____, ____, ____, wall, ____, ____, ____, ____, ____, ____, ____, ____],
    [____, ____, ____, ____, ____, ____, ____, ____, wall, port, ____, ____, ____, port, wall, ____, ____, ____, ____, ____, ____, ____, ____],
    [____, ____, ____, ____, ____, ____, ____, ____, wall, wall, wall, img3, wall, wall, wall, ____, ____, ____, ____, ____, ____, ____, ____],
    [____, ____, ____, ____, ____, ____, ____, ____, ____, ____, wall, img3, wall, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____],
    [____, ____, ____, ____, ____, ____, ____, ____, ____, ____, wall, img3, wall, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____],
    [____, wall, wall, wall, wall, wall, ____, ____, wall, wall, wall, img3, wall, wall, wall, ____, wall, wall, wall, wall, wall, wall, ____],
    [____, wall, ____, ____, ____, wall, ____, ____, wall, img3, img3, img3, img3, img3, wall, ____, wall, bap5, bap6, bap7, bap8, wall, ____],
    [____, wall, ____, ____, ____, wall, wall, wall, wall, img3, bas1, bas1, bas1, img3, wall, wall, wall, ____, ____, ____, ____, wall, ____],
    [____, wall, ____, ____, ____, img3, img3, img3, img3, img3, bas1, bap1, bas1, img3, img3, img3, img3, ____, ____, ____, ____, wall, ____],
    [____, wall, ____, ____, ____, wall, wall, wall, wall, img3, bas1, bas1, bas1, img3, wall, wall, wall, ____, ____, ____, ____, wall, ____],
    [____, wall, ____, ____, atmg, wall, ____, ____, wall, img3, img3, img3, img3, img3, wall, ____, wall, bap1, bap2, bap3, bap4, wall, ____],
    [____, wall, wall, wall, wall, wall, ____, ____, wall, wall, wall, img3, wall, wall, wall, ____, wall, wall, wall, wall, wall, wall, ____],
    [____, ____, ____, ____, ____, ____, ____, ____, ____, ____, wall, img3, wall, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____],
    [____, ____, ____, ____, ____, ____, ____, ____, ____, ____, wall, img3, wall, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____],
    [____, ____, ____, ____, ____, ____, ____, ____, wall, wall, wall, img3, wall, wall, wall, ____, ____, ____, ____, ____, ____, ____, ____],
    [____, ____, ____, ____, ____, ____, ____, ____, wall, img3, imge, img3, imge, img3, wall, ____, ____, ____, ____, ____, ____, ____, ____],
    [____, ____, ____, ____, ____, ____, ____, ____, wall, img3, imge, img3, imge, img3, wall, ____, ____, ____, ____, ____, ____, ____, ____],
    [____, ____, ____, ____, ____, ____, ____, ____, wall, img3, imge, img3, imge, img3, wall, ____, ____, ____, ____, ____, ____, ____, ____],
    [____, ____, ____, ____, ____, ____, ____, ____, wall, wall, wall, wall, wall, wall, wall, ____, ____, ____, ____, ____, ____, ____, ____],
    [____, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____, ____]
];

module.exports = room_tiles_test;